<?php
  echo "<h2>welcome to myproject (pornphun wongwat)</h2>";
  echo "<hr>
  |<a href ='index.php'> Home </a>
  |<a href ='aboutus.php'> About us </a>
  |<a href ='myproject.php'> My project </a>
  |<a href ='mycode.php'> My code </a>
  |<a href ='Contactus.php'> Contact us|</a>
  <hr>";
?>
