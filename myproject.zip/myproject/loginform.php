<b> เข้าสู่ระบบ </b>
<form method = "post" Action = "login2.php">
Username : <input type ="text" name = "username">
Password : <input type ="password" name ="password">
           <input type ="submit" value ="Login">
</form>
