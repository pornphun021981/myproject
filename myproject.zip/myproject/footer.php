<?php
echo "<br>
<Div Align ='center'>
Copyright&copy2017;by Pornphun.com All Righr Reserved
</Div>";

 ?>
