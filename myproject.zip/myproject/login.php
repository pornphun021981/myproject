username <?php echo $_POST["username"];?><br>
password : <?php echo $_POST["password"];?>
