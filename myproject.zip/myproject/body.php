
<table border ='1' width ="100%">
  <tr><td width ="80%">
    <?php include "welcome.php";?>
    <?php include "bitnews.php";?>

   </td>
        <td width ="80%"> <?php include "loginform.php";?> </td>
  </tr>
</table>
